let palavra; // criando a variável

function setup() {
  createCanvas (400, 400); // criando cenário 
  
  let palavras = [ "Caminhate","Caminho", "Caminha"];// criando as palavras 
  palavra = random (palavras) // criando a variável palavra
}

function inicializaCores () {
  background( "white") // cor do fundo
  fill ("black") // cor da letra
  textSize (60); // tamanho das letras 
  textAlign(CENTER, CENTER) // função para alinhar o texto no centro
  } // criando a função "inicialiaCores"

function draw () { 
inicializaCores()
  
  let maximo = width; // variável "maximo"
  let minimo = 0;// variável "minimo"
  
  let quantidade = map(mouseX, 0, width, 1, palavra.length)// quantidade de letras que serão utilizadas, sempre vai iniciar com o "A"
  let parcial = palavra.substring(0, quantidade); // separando as letras
  text(parcial, 200, 200); //posição do texto
  
}